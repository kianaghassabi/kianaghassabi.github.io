#libs
import numpy as np
import os
import nltk
from nltk.stem import WordNetLemmatizer
import math
import time
import hashlib
import mysql.connector
import sys

SampleSize = sys.argv[1]
ifdemaru= sys.argv[2]
threshold=sys.argv[3]
chunkSize=sys.argv[4]

if len(sys.argv) < 5 or len(sys.argv) > 5:
    print("please enter 4 Variables: Samplesize(number of emails) , True/False , threshold(3 is ideal) , chunkSize")
    sys.exit(1)


### function for levenshtein and demaru levenshtein ###
def damerau_levenshtein_distance(string1, string2):
    n1 = len(string1)
    n2 = len(string2)
    return _levenshtein_distance_matrix(string1, string2, True)[n1, n2]

def get_ops(string1, string2, is_damerau=False):
    i, j = _levenshtein_distance_matrix(string1, string2, is_damerau).shape
    i -= 1
    j -= 1
    ops = list()
    while i != -1 and j != -1:
        if is_damerau:
            if i > 1 and j > 1 and string1[i-1] == string2[j-2] and string1[i-2] == string2[j-1]:
                if dist_matrix[i-2, j-2] < dist_matrix[i, j]:
                    ops.insert(0, ('transpose', i - 1, i - 2))
                    i -= 2
                    j -= 2
                    continue
        index = np.argmin([dist_matrix[i-1, j-1], dist_matrix[i, j-1], dist_matrix[i-1, j]])
        if index == 0:
            if dist_matrix[i, j] > dist_matrix[i-1, j-1]:
                ops.insert(0, ('replace', i - 1, j - 1))
            i -= 1
            j -= 1
        elif index == 1:
            ops.insert(0, ('insert', i - 1, j - 1))
            j -= 1
        elif index == 2:
            ops.insert(0, ('delete', i - 1, i - 1))
            i -= 1
    return ops

def execute_ops(ops, string1, string2):
    strings = [string1]
    string = list(string1)
    shift = 0
    for op in ops:
        i, j = op[1], op[2]
        if op[0] == 'delete':
            del string[i + shift]
            shift -= 1
        elif op[0] == 'insert':
            string.insert(i + shift + 1, string2[j])
            shift += 1
        elif op[0] == 'replace':
            string[i + shift] = string2[j]
        elif op[0] == 'transpose':
            string[i + shift], string[j + shift] = string[j + shift], string[i + shift]
        strings.append(''.join(string))
    return strings

def _levenshtein_distance_matrix(string1, string2, is_damerau=False):
    n1 = len(string1)
    n2 = len(string2)
    d = np.zeros((n1 + 1, n2 + 1), dtype=int)
    for i in range(n1 + 1):
        d[i, 0] = i
    for j in range(n2 + 1):
        d[0, j] = j
    for i in range(n1):
        for j in range(n2):
            if string1[i] == string2[j]:
                cost = 0
            else:
                cost = 1
            d[i+1, j+1] = min(d[i, j+1] + 1, # insert
                              d[i+1, j] + 1, # delete
                              d[i, j] + cost) # replace
            if is_damerau:
                if i > 0 and j > 0 and string1[i] == string2[j-1] and string1[i-1] == string2[j]:
                    d[i+1, j+1] = min(d[i+1, j+1], d[i-1, j-1] + cost) # transpose
    return d


# 1 - get data from dataset
def convertTupletoStrTRAIN(tup): 
    """ Convert tuple to string (used in reading messages from database)
    """
    str =  ''.join(tup) 
    return str
    
#Read messages from dataset  
def getClientmsg():
    """ get messages form Database 
    """
    db = mysql.connector.connect(user='root',password='123456',host='127.0.0.1',database='new_database',auth_plugin='mysql_native_password')
                         
    cursor = db.cursor()
    query='SELECT body FROM message LIMIT %s'
    var=(int(SampleSize),)
    cursor.execute(query,var)
    data = cursor.fetchall()
    Strdat=[]
    for i in data:
        Strdat.append(convertTupletoStrTRAIN(i))
    db.close()
    return Strdat


Emails=getClientmsg()


# 1.1 Calculate storage without any deduplication - RAW storage
# convert bit to megabyte
def convert_Bit_to_Megabyte(bit):
    Megabyte=bit/(1024*1024*8)
    return Megabyte

#storage of a single word
def CalCharsbit(word):
    wordcount=len(word)*8
    return wordcount

#storage of a list
def calstorageofList(alist):
    strforlist=0
    for i in alist:
        strforlist+=CalCharsbit(i)
    return strforlist

#calculate storag without any deduplication
liststr=[]
for i in Emails:
    strforlist=calstorageofList(i)
    liststr.append(strforlist)

# 1.2 write the storage information into a file
file1 = open('chunk '+str(chunkSize)+'  Enron -'+ str(SampleSize)+' samples - GD - DL is '+str(ifdemaru)+' - tresh is '+str(threshold)+' res.txt', 'w')
file1.write("BEFORE: Total storage for given dataset is equal to: "+ str(convert_Bit_to_Megabyte(sum(liststr))) + " Megabytes and "+ str(sum(liststr))+" bits.\n")
file1.close()


start_chunking=time.time()
# 2 - Apply chunking 
print("******* chunking STARTED ******")
def chunking(sampleEmail):
    # print("sampleEmail",sampleEmail)
    words  = [sampleEmail[i:i+int(chunkSize)] for i in range(0, len(sampleEmail), int(chunkSize))]
    lastelement=words.pop() 
    words.append(lastelement.ljust(int(chunkSize), '0'))
    return words
    
chunked=[]
for rev in Emails:
    chunked.append(chunking(rev))
# chunked is a list of lists [each list contatin the chunked form of the word]


end_chunking=time.time()

tokentime=end_chunking-start_chunking

numberfowords=0
for i in chunked:
    numberfowords+=len(i)

print("------- chunking FINISHED -------\n ")

# 3 - Extract bases - find deviations
print("******* Exctaracting Bases\ devs STARTED ******")

start_trsnformationtime=time.time()

wordnet_lemmatizer = WordNetLemmatizer()
LemmBases=[]
devsStorageLemm=[]
for singlerev in chunked:    
    for word in singlerev:
        devsize=0
        #extract base
        if len(word)<15:

            BaseLemm=wordnet_lemmatizer.lemmatize(word)
            
            dist_matrix = _levenshtein_distance_matrix(BaseLemm, word, is_damerau=ifdemaru)
            # print(dist_matrix)
            ops = get_ops(BaseLemm, word, is_damerau=ifdemaru)
            numofedits=len(ops)
            # print(ops)
            if numofedits>0 and numofedits<int(threshold):
                for i in range(len(ops)):
                    if ops[i][0]=='delete':
                        devsize+=2+math.ceil(math.log2(len(BaseLemm)))
                    elif ops[i][0]=='transpose':
                        devsize+=(2+math.ceil(math.log2(len(word)))+math.ceil(math.log2(len(BaseLemm))))
                    elif ops[i][0]=='replace':
                        devsize+=(2+math.ceil(math.log2(len(word)))+math.ceil(math.log2(len(BaseLemm))))
                    elif ops[i][0]=='insert':
                        devsize+=(2+math.ceil(math.log2(len(word)))+math.ceil(math.log2(len(BaseLemm))))
                devsStorageLemm.append(devsize)
                LemmBases.append(BaseLemm)
            else:
                LemmBases.append(word)
        else:
            LemmBases.append(word)

        # print(devsStorageLemm)
        # res = execute_ops(ops, string1, string2)
        # print(res)

print("------- Exctaracting Bases\devs FINISHED -------\n")

end_trsnformationtime=time.time()
trstime=start_trsnformationtime-end_trsnformationtime

# 4 - Deduplication on Bases
print("******* Deduplication STARTED ******")

BasesDict=[] 
#storage for pointers in incremental mode for each new word added to base
newwordstorage=0
duplicatepoiner=0
#pointers to count
pointertobase=0
alreadyexistpointer=0
duplicateones=[]
hasheddict=[]
basestorage=0

st = time.time()
for word in LemmBases:
    ha=hashlib.sha1(word.encode())
    hashed=ha.hexdigest()
    #if the bases dictionary hasnt filled yet
    if len(BasesDict)==0:
        BasesDict.append(word)
        hasheddict.append(hashed)
        basestorage+=len(word)*8
        currentbasesize=len(BasesDict)
        newwordstorage+=math.ceil(math.log2(currentbasesize))

    elif hashed in hasheddict:
        currentbasesize=len(BasesDict)
        duplicatepoiner+=math.ceil(math.log2(currentbasesize))
        duplicateones.append(word)

    else:
        BasesDict.append(word)
        hasheddict.append(hashed)
        basestorage+=len(word)*8
        currentbasesize=len(BasesDict)
        newwordstorage+=math.ceil(math.log2(currentbasesize))

et= time.time()
res = et - st

print("-------  Deduplication FINISHED -------\n ")

# 4.1 compute storage
dupstorage=0
for i in duplicateones:
    for j in i:
        dupstorage+=len(j) *8

file1 = open('chunk '+str(chunkSize)+'  Enron -'+ str(SampleSize)+' samples - GD - DL is '+str(ifdemaru)+' - tresh is '+str(threshold)+' res.txt', 'a')
file1.write("\n\n\t - after chunking we have "+str(numberfowords)+" words in total.")
file1.write("\n\n\t - chunksize = "+str(chunkSize))
file1.write("\n\n\t - demaru lev = "+str(ifdemaru))
file1.write("\n\n\t - threhsold is = "+str(threshold))
file1.write("\n\n\t - storage of pointer to already existed base= "+str(convert_Bit_to_Megabyte(duplicatepoiner)))
file1.write("\n\n\t - new word pointers ( saved as base) storage is equal to "+str(convert_Bit_to_Megabyte(newwordstorage))+"  megabytes -> work as registry")
file1.write("\n\n\t - number of bases:"+ str(len(BasesDict)))
file1.write("\n\n\t - storage of bases in megabyte= "+str(convert_Bit_to_Megabyte(basestorage)))
file1.write("\n\n\t - deviation storage=  "+str(convert_Bit_to_Megabyte(sum(devsStorageLemm))))
file1.write("\n\n\t - number of duplicates:"+ str(len(duplicateones)))
file1.write("\n\n\t - storage of duplicates in megabyte= "+str(convert_Bit_to_Megabyte(dupstorage)))

total=convert_Bit_to_Megabyte(duplicatepoiner+basestorage+sum(devsStorageLemm))
totalminus=convert_Bit_to_Megabyte(duplicatepoiner+basestorage)

file1.write("\n\n\n######################################################################################################\n")
file1.write("\n\n\t - total storage (ptr to already+base+dev) is equal to "+str(total)+"  megabytes")
file1.write("\n\n\t - total storage (ptr to already+base) is equal to "+str(totalminus)+"  megabytes")
file1.write("\n\n\n######################################################################################################\n")
file1.write("\n\n\t - execution time in mins = "+str(res/60)+" and seconds: "+str(res))
file1.write("\n\n\t - transformation time in mins = "+str(trstime/60)+" and seconds: "+str(trstime))
file1.write("\n\n\t - chunking time in mins = "+str(tokentime/60)+" and seconds: "+str(tokentime))


file1.close()