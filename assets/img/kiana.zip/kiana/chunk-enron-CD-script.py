#libs
import numpy as np
import os
import nltk
from nltk.stem import WordNetLemmatizer
import math
import time
import hashlib
import mysql.connector
import sys

SampleSize = sys.argv[1]
chunkSize=sys.argv[2]

if len(sys.argv) < 3 or len(sys.argv) > 3:
    print("please enter 3 Variables: Samplesize(number of emails) , Chunksize ")
    sys.exit(1)

# 1 - get data from dataset
def convertTupletoStrTRAIN(tup): 
    """ Convert tuple to string (used in reading messages from database)
    """
    str =  ''.join(tup) 
    return str
    
#Read messages from dataset  
def getClientmsg():
    """ get messages form Database 
    """
    db = mysql.connector.connect(user='root',password='123456',host='127.0.0.1',database='new_database',auth_plugin='mysql_native_password')
                         
    cursor = db.cursor()
    query='SELECT body FROM message LIMIT %s'
    var=(int(SampleSize),)
    cursor.execute(query,var)
    data = cursor.fetchall()
    Strdat=[]
    for i in data:
        Strdat.append(convertTupletoStrTRAIN(i))
    db.close()
    return Strdat

Emails=getClientmsg()


# 1.1 Calculate storage without any deduplication - RAW storage
# convert bit to megabyte
def convert_Bit_to_Megabyte(bit):
    Megabyte=bit/(1024*1024*8)
    return Megabyte

#storage of a single word
def CalCharsbit(word):
    wordcount=len(word)*8
    return wordcount

#storage of a list
def calstorageofList(alist):
    strforlist=0
    for i in alist:
        strforlist+=CalCharsbit(i)
    return strforlist

#calculate storag without any deduplication
liststr=[]
for i in Emails:
    strforlist=calstorageofList(i)
    liststr.append(strforlist)

# 1.2 write the storage information into a file
file1 = open(str(chunkSize)+' chunk Enron -'+ str(SampleSize)+' samples - CD res.txt', 'w')
file1.write("BEFORE: Total storage for given dataset is equal to: "+ str(convert_Bit_to_Megabyte(sum(liststr))) + " Megabytes and "+ str(sum(liststr))+" bits.\n")
file1.close()


start_chunking=time.time()
# 2 - Apply chunking or chunking
print("******* chunking STARTED ******")
def chunking(sampleEmail):
    # print("sampleEmail",sampleEmail)
    words  = [sampleEmail[i:i+int(chunkSize)] for i in range(0, len(sampleEmail), int(chunkSize))]
    lastelement=words.pop() 
    words.append(lastelement.ljust(int(chunkSize), '0'))
    return words
    
chunked=[]
for rev in Emails:
    chunked.append(chunking(rev))
end_chunking=time.time()

chunktime=end_chunking-start_chunking

numberfowords=0
for i in chunked:
    numberfowords+=len(i)


print("------- chunking FINISHED -------\n ")

# 4 - Deduplication on Bases
print("******* Deduplication STARTED ******")

BasesDict=[] 
#storage for pointers in incremental mode for each new word added to base
newwordstorage=0
duplicatepoiner=0
#pointers to count
pointertobase=0
alreadyexistpointer=0
duplicateones=[]
hasheddict=[]
basestorage=0

st = time.time()
for singlerev in chunked:    
    for word in singlerev:
        ha=hashlib.sha1(word.encode())
        hashed=ha.hexdigest()
        #if the bases dictionary hasnt filled yet
        if len(BasesDict)==0:
            BasesDict.append(word)
            hasheddict.append(hashed)
            basestorage+=len(word)*8
            currentbasesize=len(BasesDict)
            newwordstorage+=math.ceil(math.log2(currentbasesize))

        elif hashed in hasheddict:
            currentbasesize=len(BasesDict)
            duplicatepoiner+=math.ceil(math.log2(currentbasesize))
            duplicateones.append(word)

        else:
            BasesDict.append(word)
            hasheddict.append(hashed)
            basestorage+=len(word)*8
            currentbasesize=len(BasesDict)
            newwordstorage+=math.ceil(math.log2(currentbasesize))

et= time.time()
res = et - st

print("-------  Deduplication FINISHED -------\n ")

# 4.1 compute storage
dupstorage=0
for i in duplicateones:
    for j in i:
        dupstorage+=len(j) *8

file1 = open(str(chunkSize)+' chunk Enron -'+ str(SampleSize)+' samples - CD res.txt', 'a')
file1.write("\n\n\t - storage of pointer to already existed base= "+str(convert_Bit_to_Megabyte(duplicatepoiner)))
file1.write("\n\n\t - new word pointers ( saved as base) storage is equal to "+str(convert_Bit_to_Megabyte(newwordstorage))+"  megabytes -> work as registry")
file1.write("\n\n\t - number of bases:"+ str(len(BasesDict)))
file1.write("\n\n\t - storage of bases in megabyte= "+str(convert_Bit_to_Megabyte(basestorage)))
file1.write("\n\n\t - number of duplicates:"+ str(len(duplicateones)))
file1.write("\n\n\t - storage of duplicates in megabyte= "+str(convert_Bit_to_Megabyte(dupstorage)))

totalminus=convert_Bit_to_Megabyte(duplicatepoiner+basestorage)

file1.write("\n\n\n######################################################################################################\n")
file1.write("\n\n\t - total storage (ptr to already+base) is equal to "+str(totalminus)+"  megabytes")
file1.write("\n\n\n######################################################################################################\n")
file1.write("\n\n\t - execution time in mins = "+str(res/60)+" and seconds: "+str(res))
file1.write("\n\n\t - chunking time in mins = "+str(chunktime/60)+" and seconds: "+str(chunktime))


file1.close()